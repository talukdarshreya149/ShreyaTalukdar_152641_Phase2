package com.cg.mypaymentapp.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;
import com.cg.mypaymentapp.util.DBUtil;

public class WalletDaoImpl implements WalletDao {
	
	static Connection con = null;
	
	public WalletDaoImpl() {
		
		try {
			con = DBUtil.getConnect();
		} catch (Exception e) {
			
		}
	}
	
	public String save(Customer customer) {
		try {
			String sql="INSERT INTO CustomerDetails VALUES(?,?,?)";
            PreparedStatement pstmt=con.prepareStatement(sql);
			
			pstmt.setString(1, customer.getMobileNo());
			pstmt.setString(2, customer.getName());
			pstmt.setBigDecimal(3, customer.getWallet());
			
			pstmt.executeUpdate();
			
		} catch(SQLException e) {
			
		}
		
		return customer.getMobileNo();
	}

	public Customer findOne(String mobileNo) throws InvalidInputException {
		
		Customer customer=new Customer();
		try {
			String sql= "SELECT * FROM customerdetails WHERE mobileno= ?";
            PreparedStatement pstmt = con.prepareStatement(sql);
			
            pstmt.setString(1,mobileNo);
			
            ResultSet res=pstmt.executeQuery();
			if(res.next()) {
				customer.setMobileNo(res.getString(1));
				customer.setName(res.getString(2));
				customer.setWallet(res.getBigDecimal(3));
			} 
			
		} catch(SQLException e) {
		    }
	
		return customer;
				
	}

	public boolean checkMobile(String mobileNo) {
		boolean flag=false;
		
		String query= "SELECT * FROM customerdetails WHERE mobileno = ?";	
		try{
			
			PreparedStatement pstmt = con.prepareStatement(query);
		    pstmt.setString(1, mobileNo);
		   
		    ResultSet res=pstmt.executeQuery();
	if(res.next()) 
			flag=true;
			
		} catch(SQLException e) {	
			
		}

   return flag;
	}

	public void addTransaction(String mobileNo, String transaction) {

		try{
		
		String sql= "INSERT INTO TRANSACTION VALUES(?,?)";	
        PreparedStatement pstmt = con.prepareStatement(sql);
		
        pstmt.setString(1, mobileNo);
		pstmt.setString(2, transaction);
        pstmt.executeUpdate();
		
		} catch(Exception e) {
			
			}
	}

	public ArrayList<String> printTransactions(String mobileNo) throws InvalidInputException {
		
		ArrayList<String> transactionList=new ArrayList<String>();
		String sql="SELECT * FROM TRANSACTION WHERE MOBILE= ?";
		try {
			
			PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setString(1, mobileNo);
			
			ResultSet res=pstmt.executeQuery();
			
			if(res.next()==false) { 
				throw new InvalidInputException("error");
			} else {
				
				while(res.next()) {
					transactionList.add(res.getString(2));
				}
			}
		} catch(Exception e) {
			
		}
		return transactionList;
	}

	public void updatewallet(String mobileNo, BigDecimal amount) {
		try {
			
			String sql= "UPDATE customerdetails SET wallet= ?  WHERE mobileno= ?";	
	        PreparedStatement pstmt = con.prepareStatement(sql);
			pstmt.setBigDecimal(1, amount);
			pstmt.setString(2, mobileNo);
	       
			pstmt.executeUpdate();
		
		}catch (Exception e) {
			
		}
		
	}

	

}

