package com.cg.mypaymentapp.exception;

public interface IInsufficientbalanceException {
String ERROR1="Insufficient Balance Cannot Withdraw";
String ERROR2="Insufficient Balance Cannot Transfer";
}
