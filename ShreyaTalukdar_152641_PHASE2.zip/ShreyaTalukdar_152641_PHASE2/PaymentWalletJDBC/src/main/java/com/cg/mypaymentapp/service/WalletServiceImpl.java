package com.cg.mypaymentapp.service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import javax.imageio.metadata.IIOInvalidTreeException;

import com.cg.mypaymentapp.bean.Customer;
import com.cg.mypaymentapp.dao.WalletDao;
import com.cg.mypaymentapp.dao.WalletDaoImpl;
import com.cg.mypaymentapp.exception.IInsufficientbalanceException;
import com.cg.mypaymentapp.exception.IInvalidInputException;
import com.cg.mypaymentapp.exception.InsufficientBalanceException;
import com.cg.mypaymentapp.exception.InvalidInputException;

public class WalletServiceImpl implements WalletService {
	
 private WalletDao dao=null;
	
	public WalletServiceImpl(){
		dao= new WalletDaoImpl();
	}
	

	public void createAccount(Customer customer) {
		
		dao.save(customer);
	}

	public boolean checkMobile(String mobileNo) {
		
		return dao.checkMobile(mobileNo);
	}

	public Customer findOne(String mobileNo) throws InvalidInputException {
		
		return dao.findOne(mobileNo);
	}

	public Customer showBalance(String mobileno) {
	
		return dao.findOne(mobileno);
	}

	public Customer fundTransfer(String sourceMobileNo, String targetMobileNo, BigDecimal amount) throws InvalidInputException {
		
		
		Customer senderDetails=dao.findOne(sourceMobileNo);
		Customer receiverDetails=dao.findOne(targetMobileNo);
		
		BigDecimal senderBal=senderDetails.getWallet();
		senderBal=senderBal.subtract(amount);
		senderDetails.setWallet(senderBal);
		dao.updatewallet(sourceMobileNo, senderBal);
		
		BigDecimal receiverbal=senderDetails.getWallet();
		receiverbal=receiverbal.add(amount);
		receiverDetails.setWallet(receiverbal);	
		dao.updatewallet(targetMobileNo,receiverbal);
		
		dao.addTransaction(sourceMobileNo, amount+"Amount Transferred from" + sourceMobileNo+" to"+ targetMobileNo+" Current balance");
		
				
		return senderDetails;
	}

	public Customer depositAmount(String mobileNo, BigDecimal amount) throws InvalidInputException {
			
		Customer cust=dao.findOne(mobileNo);
		
		BigDecimal finalAmt=cust.getWallet().add(amount);
		cust.setWallet(finalAmt);
		dao.updatewallet(mobileNo, finalAmt);
		dao.addTransaction(mobileNo, amount+ "Deposited to" + mobileNo+ "Current Balance"+ finalAmt+ "at" + LocalDateTime.now());
	
		return cust;
	}

	public Customer withdrawAmount(String mobileNo, BigDecimal amount) {
		
		Customer cust1=dao.findOne(mobileNo);

       BigDecimal finalAmt1=cust1.getWallet().subtract(amount);
		cust1.setWallet(finalAmt1);
		dao.updatewallet(mobileNo, finalAmt1);
		dao.addTransaction(mobileNo, amount+ " Amount Withdrawn from" + mobileNo+ "Current Balance"+ finalAmt1+ "at" + LocalDateTime.now());
	
		return cust1;
		
	}

	public ArrayList<String> printTransactions(String mobileNo) throws InvalidInputException {
		
		return dao.printTransactions(mobileNo);
	}

	public boolean inputValidation(String name, String mobileNo) throws InvalidInputException {
		
		boolean result=false;
		if(name.trim().matches("^[A-Z a-z]*$")) {
			if(mobileNo.length()==10) {
				result=true;
			}else {
				throw new InvalidInputException(IInvalidInputException.ERROR1);
			}
		}else {
			throw new InvalidInputException(IInvalidInputException.ERROR2);
		}
		return result;
	}


	public boolean balanceValidation(BigDecimal amount, String mobNo) throws InsufficientBalanceException {
		
		boolean result=false;
		BigDecimal balance=dao.findOne(mobNo).getWallet();
		if(amount.compareTo(balance)==-1) {  //amount is greater than amount
			result=true;
			
		}else {
			throw new InsufficientBalanceException(IInsufficientbalanceException.ERROR1);
		}
		return result;
	}


	public boolean mobileValidation(String mobile) throws InvalidInputException {
	
		 boolean result=false;
		 if(mobile.length()==10) {
			 result=true;
			 
		 } else {
			 throw  new InvalidInputException(IInvalidInputException.ERROR1);
		 }
		 
		 return result;
	}


	public boolean transferValidation(BigDecimal amount, String mobNoS) throws InsufficientBalanceException {
		// TODO Auto-generated method stub
		boolean result=false;
		BigDecimal bal1=dao.findOne(mobNoS).getWallet();
		if(amount.compareTo(bal1)==-1) {
			result=true;
		}else {
			throw new InsufficientBalanceException(IInsufficientbalanceException.ERROR2);
		}
		return result;
	}


	


	


	
}
